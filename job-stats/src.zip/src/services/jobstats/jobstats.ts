export interface JobStats {
    jobName?: string;
    runDate?: string;
    jobID?: number;
    startTime?: string;
    endTime?: string;
    runTime?: string;
    status?: string;
}